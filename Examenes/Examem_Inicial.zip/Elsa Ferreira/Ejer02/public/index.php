<?php


require "../vendor/autoload.php";
use App\interfaces\Encendible;
use App\clases\Bombilla;
use App\clases\Coche;



$miCoche= new Coche();
$miBombila= new Bombilla(10);


function enciende_algo(Encendible $encendible){
    $encendible->encender();
};

function apaga_algo(Encendible $encendible){
    $encendible->apagar();
};


enciende_algo($miCoche);
enciende_algo($miBombila);
apaga_algo($miCoche);
$miCoche->repostar(30);
enciende_algo($miCoche);



?>