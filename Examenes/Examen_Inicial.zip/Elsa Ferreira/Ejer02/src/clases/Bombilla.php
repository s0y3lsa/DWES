<?php
namespace App\clases;
use App\interfaces\Encendible;

class Bombilla implements Encendible{

   private int $horasdevida;

    public function __construct(int $horasdevida)
    {
           $this->horasdevida=$horasdevida;
    }

        public function encender():void{
            if($this->horasdevida>1){
                echo "bombilla encendida <br/>";
                $this->horasdevida-=2;
            }else{
                echo "bombilla apagada <br/>";
            }
           
        }

        public function apagar():void{
            echo "Se ha apagado la bombilla <br/>";
        }
        
        public function sethorasdevida($horasdevida){
            $this->horasdevida=$horasdevida;
        }
        public function gethorasdevida($horasdevida){
            $this->horasdevida=$horasdevida;
        }
}


?>