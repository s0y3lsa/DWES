<?php
namespace App\clases;
use App\interfaces\Encendible;

class Coche implements Encendible{

    private int $gasolina;
    private int $bateria;
    private bool $estado; 

    public function __construct(){
            $this->gasolina=0;
            $this->bateria=10;
            $this->estado=false;
    }

    public function encender():void{
        if($this->gasolina>0 && $this->bateria>0 && !$this->estado){
            
            echo "Se ha arrancado el coche <br/>";
            $this->gasolina-=1;
            $this->bateria-=1; 
            $this->estado=true;


        }else{
            echo "No se pudo arrancar el coche <br/>";
        }
    }

    public function apagar():void{
         
        if($this->estado){
            echo "El coche esta apagado <br/>";
            $this->estado=false;
        }else{
            echo "no se puede apagar el coche <br/>";
        }
    }

    public function repostar(int $litros):void{
        if($litros>0){
                $this->gasolina+=$litros;
                echo "repone coche  </br>";
        }else{
            echo "No repone coche </br>";
        }
    }

}


?>


