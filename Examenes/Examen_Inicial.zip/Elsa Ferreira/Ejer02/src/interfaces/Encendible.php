<?php
namespace App\interfaces;

interface Encendible{
    public function encender():void;
    public function apagar():void;
}
?>