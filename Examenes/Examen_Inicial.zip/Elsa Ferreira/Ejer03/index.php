<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form action method="post">

        <label for="nombre">Numero de nombres: </label>
        <input type="number" id="nombre" name="nombre" value=echo (isset($_POST['Cargar'])?:$_POST['nombre']:0) >

        <br>

        <label for="email">Numero de emails: </label>
        <input type="number" id="email" namme="email" value=echo (isset($_POST['Cargar'])?:$_POST['email']:0) >
        <br>
        <label for="telefono">Numero de telefonos moviles: </label>
        <input type="number" id="numero" name="numero" value= echo (isset($_POST['Cargar'])?:$_POST['numero']:0) >
        <br>
        <input type="submit" name="Cargar" value="Cargar">
        
    </form>

    <?php
    require_once 'validaciones.php';

    //numero de nombres 
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        if(isset($_POST['nombre']) && isset($_POST['email']) && isset($_POST['telefono']) ){
            $nombre = $_POST["nombre"];
            $email = $_POST["email"];
            $telefono = $_POST["telefono"];
        }
    }
    
    
    
    
    ?>
</body>
</html>