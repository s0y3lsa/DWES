
<?php
interface Encendible{
    public function encender();
    public function apagar();
}
?>