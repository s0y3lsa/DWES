<!DOCTYPE html>

<html>
    <head>
        <meta charset="UFT-8">´
        <tittle>Ejercicio01_hoja02</tittle>
    </head>
    <body>

        <?php
        
        print ""
        ?>
    </body>
</html>