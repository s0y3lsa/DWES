<!DOCTYPE html>
<html>

<head>
    <meta charset="UFT-8">
</head>
<body>

    <?php

        print"Segundo ejercicio: visualizacióndel contenido de variables<br>";
        $nombre="Elsa";
        $edad=20;

        //mostrar datos 
        print "Mi nombre es $nombre y mi edad es $edad"
    ?>

</body>
</html>