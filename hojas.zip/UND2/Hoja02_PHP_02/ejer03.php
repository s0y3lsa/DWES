<!DOCTYPE html>
<html>

<head>
    <meta charset="UFT-8">
</head>
<body>

    <?php
            $operador1=13;
            $operador2=4;

            //resta
            $resultado=$operador1-$operador2;
            print "$operador1-$operador2=$resultado<br>";

            //suma 
            $resultado=$operador1+$operador2;
            print "$operador1+$operador2=$resultado<br>";

            //multiplicacion 
            $resultado=$operador1*$operador2;
            print "$operador1*$operador2=$resultado<br>";

            //división
            $resultado=$operador1/$operador2;
            print "$operador1/$operador2=$resultado<br>";

            //resto de la divison 
            $resultado=$operador1%$operador2;
             print "$operador1%$operador2=$resultado<br>";


    ?>
</body>
</html>