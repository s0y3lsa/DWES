<!DOCTYPE html>
<html>
<head>
    <meta charset="UFT-8">
</head>
<body>
    
    <?php
        $variable1=2;
        $variable2=10;
        $variable3=8;

        $suma=$variable1+$variable2+$variable3;
        $resultado=$suma/3;

        print"La media de los tres numeros de $variable1, $variable2,$variable3
        es $resultado <br>"


    ?>

</body>
</html>
